import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

const Scene3D = () => {
  const mountRef = useRef(null);

  const modelRef = useRef();
  const originalMaterials = useRef({});
  const intersectedMaterial = useRef(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x55ff55,
      emissiveIntensity: 0.5,
    })
  );

  useEffect(() => {
    const currentMount = mountRef.current;
    if (!currentMount) return;

    // === 1. SETUP BÁSICO ===
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      currentMount.clientWidth / currentMount.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 15;

    // *** CORREÇÃO PRINCIPAL: Desativar o canal alpha ***
    // O renderer agora terá seu próprio fundo opaco (que será o skybox).
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: false, // Garante que o canvas não seja transparente
    });
    renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    currentMount.appendChild(renderer.domElement);

    // === 2. SKYBOX ===
    const cubeTextureLoader = new THREE.CubeTextureLoader();
    cubeTextureLoader.setPath("/skybox/");
    const skyboxTexture = cubeTextureLoader.load([
      "px.jpg",
      "nx.jpg",
      "py.jpg",
      "ny.jpg",
      "pz.jpg",
      "nz.jpg",
    ]);
    scene.background = skyboxTexture;

    // === 3. ILUMINAÇÃO ===
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 2);
    directionalLight.position.set(10, 15, 10);
    scene.add(directionalLight);

    // === 4. CARREGAR O MODELO 3D (.glb) ===
    const loader = new GLTFLoader();
    loader.load(
      "/models/card_deck_suits.glb",
      (gltf) => {
        modelRef.current = gltf.scene;

        const box = new THREE.Box3().setFromObject(modelRef.current);
        const center = box.getCenter(new THREE.Vector3());
        modelRef.current.position.sub(center);

        modelRef.current.scale.set(20, 20, 20);

        modelRef.current.traverse((child) => {
          if (child.isMesh) {
            originalMaterials.current[child.uuid] = child.material;
          }
        });
        scene.add(modelRef.current);
      },
      undefined,
      (error) => console.error("Um erro ocorreu ao carregar o modelo", error)
    );

    // === 5. INTERATIVIDADE ===
    const keysPressed = {};
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let lastIntersected = null;

    const handleKeyDown = (event) => {
      keysPressed[event.key.toLowerCase()] = true;
    };
    const handleKeyUp = (event) => {
      keysPressed[event.key.toLowerCase()] = false;
    };
    const handleMouseMove = (event) => {
      const rect = currentMount.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const resizeObserver = new ResizeObserver(() => {
      const { clientWidth, clientHeight } = currentMount;
      renderer.setSize(clientWidth, clientHeight);
      camera.aspect = clientWidth / clientHeight;
      camera.updateProjectionMatrix();
    });
    resizeObserver.observe(currentMount);

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("mousemove", handleMouseMove);

    // === 6. LOOP DE ANIMAÇÃO ===
    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (modelRef.current) {
        if (keysPressed["a"]) modelRef.current.rotation.y += 0.02;
        if (keysPressed["d"]) modelRef.current.rotation.y -= 0.02;
        if (keysPressed["w"]) modelRef.current.rotation.x += 0.02;
        if (keysPressed["s"]) modelRef.current.rotation.x -= 0.02;
      }

      raycaster.setFromCamera(mouse, camera);
      const intersects = modelRef.current
        ? raycaster.intersectObjects(modelRef.current.children, true)
        : [];

      if (intersects.length > 0) {
        const firstIntersected = intersects[0].object;
        if (lastIntersected !== firstIntersected) {
          if (lastIntersected)
            lastIntersected.material =
              originalMaterials.current[lastIntersected.uuid];
          firstIntersected.material = intersectedMaterial.current;
          lastIntersected = firstIntersected;
        }
      } else {
        if (lastIntersected) {
          lastIntersected.material =
            originalMaterials.current[lastIntersected.uuid];
          lastIntersected = null;
        }
      }
      renderer.render(scene, camera);
    };
    animate();

    // === 7. LIMPEZA (CLEANUP) ===
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("mousemove", handleMouseMove);
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
      if (currentMount && renderer.domElement) {
        currentMount.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} style={{ width: "100%", height: "100%" }} />;
};

export default Scene3D;
